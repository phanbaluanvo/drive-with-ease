package com.example.drivewithease

data class RentalCar(
    val model: String,
    val make: String,
    val price: Int,
    val isAvailable: Boolean,
    val imageResourceId: Int
)
