package com.example.drivewithease

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.drivewithease.R

class CarAdapter(private val carList: List<RentalCar>) :
    RecyclerView.Adapter<CarAdapter.CarViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_car_item, parent, false)
        return CarViewHolder(view)
    }

    override fun onBindViewHolder(holder: CarViewHolder, position: Int) {
        val car = carList[position]
        holder.bind(car)
    }

    override fun getItemCount(): Int {
        return carList.size
    }

    inner class CarViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val modelTextView: TextView = itemView.findViewById(R.id.textView_model)
        private val makeTextView: TextView = itemView.findViewById(R.id.textView_make)
        private val priceTextView: TextView = itemView.findViewById(R.id.textView_price)
        private val availabilityTextView: TextView = itemView.findViewById(R.id.textView_availability)
        private val carImageView: ImageView = itemView.findViewById(R.id.imageView_car)

        fun bind(car: RentalCar) {
            modelTextView.text = car.model
            makeTextView.text = car.make
            priceTextView.text = itemView.context.getString(R.string.price_per_day, car.price)
            availabilityTextView.text = if (car.isAvailable) {
                itemView.context.getString(R.string.available)
            } else {
                itemView.context.getString(R.string.not_available)
            }

            Glide.with(itemView.context)
                .load(car.imageResourceId)
                .placeholder(R.drawable.default_car_image)
                .error(R.drawable.default_car_image)
                .into(carImageView)
        }
    }
}
