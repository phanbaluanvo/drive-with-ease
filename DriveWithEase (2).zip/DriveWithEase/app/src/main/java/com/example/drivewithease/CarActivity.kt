package com.example.drivewithease

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class CarActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car_catalogue)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView_carCatalogue)

        val carList = mutableListOf(
            RentalCar("Toyota", "Camry", 100, true, R.drawable.toyota_camry),
            RentalCar("Honda", "Accord", 120, true, R.drawable.honda_accord),
            RentalCar("Ford", "Mustang", 150, false, R.drawable.ford_mustang)
        )

        val adapter = CarAdapter(carList)

        recyclerView.adapter = adapter
    }
}
